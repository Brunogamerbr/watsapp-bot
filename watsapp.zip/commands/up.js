module.exports = async(client,msg) => {
  let user = await msg.getContact();
  if(user.id.user != "5527997809769") return;
  client.db.set('Validade', {up: Date.now()});
  msg.reply(`👍`);
};