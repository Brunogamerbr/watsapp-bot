/*const LOGIN_1 = "Preço de 1 login"


const LOGIN_2 = "Preço de 2 login"


const LOGIN_3 = "Preço de 3 login"


const CLIENTE_ID = "Cliente ID Gerencianet"


const CLIENTE_SECRET = "Cliente Secret Gerencianet"


const CPF_USER = "CPF cadastrado na gerencianet"


const NOME = "Nome completo"


const CHAVE = "Chave pix gerencianet"


const LINK_SUPORTE = "wa.me/5573000000000"


const DOWLOAD = "Dowload do seu aplicativo"


const API_KEY = "API KEY dada por @Bruno_VPN"


const DATABASE_URL = "DatabaseURL dada por @Bruno_VPN"


const NUMERO = "5573000000000"*/

const LOGIN_1 = "1.00"
const LOGIN_2 = "25.00"
const LOGIN_3 = "30.00"
const CLIENTE_ID = "Client_Id_02bc28e14932e079b91b54ad63dd94c530a9bd86"
const CLIENTE_SECRET = "Client_Secret_f5823fe5949b39383f236ec4a0ed64cb448da782"
const CPF_USER = "14110811708"
const NOME = "Eliene Da Silva Santos"
const CHAVE = "1b3eaf34-1992-4d89-9aa9-180832c37d91"
const LINK_SUPORTE = "wa.me/5527997809769"
const DOWLOAD = "https://play.google.com/store/apps/details?id=cloudvpnbeta.net"
const API_KEY = "AIzaSyA5ma-0ybzMzvNH6YLZ17VKPv0OUMG6HbU"
const DATABASE_URL = "https://watsapp-bot-56552-default-rtdb.firebaseio.com"
const NUMERO = "5527997809769"



const { Client } = require('whatsapp-web.js');
const puppeteer = require("puppeteer");
const qrcode = require('qrcode-terminal');
const firebase = require("firebase");
const GerenciaPix = require("./utilitarios/GerenciaPix.js");
const client = new Client({
  puppeteer: { 
    headless: 
    true,args: ['--no-sandbox',
    '--disable-setuid-sandbox']}
});

const PixApi = new GerenciaPix({
    sandbox: false,
    client_id: CLIENTE_ID,
    client_secret: CLIENTE_SECRET,
    pix_cert: './certificado.p12',
    cpf: CPF_USER,
    nome: NOME,
    chave_pix: CHAVE
});

const FireSimple = require("./utilitarios/DatabaseUtil.js");
client.db = new FireSimple({
apiKey: API_KEY,
databaseURL: DATABASE_URL,
temporary_files_path: "CheckUser/"
});

client.on('qr', async (codigo_qr) => {
  qrcode.generate(codigo_qr, {small: true});
  console.log("ENCANEIE O CÓDIGO QR PELO SEU WHATSAPP.")
});

client.on('ready', () => {
  console.log('BOT VENDAS FOI ATIVADO COM SUCESSO !!');
});


client.on('message', async (msg) => {
  const valid = await client.db.get("Validade");
  
  if(msg.body == "!up") {
    require("./commands/up.js")(client,msg)
  }
  
  if(msg.body == "!info") {
    require("./commands/info.js")(client,msg,NUMERO)
  }
  
  let user = await msg.getContact()
  let number = `+${user.id.user}`
  let chatID = number.substring(1) + "@c.us";

  if(msg.body == '!menu') {
  let timeout = 2592000000;

  if(valid ==  null) {
    client.sendMessage(chatID, '🔴 Essa aplicação está sem permissão de execução no momento.');
    return;
  }

  if(valid.up !== null && timeout - (Date.now() - valid.up) > 0) {
  
  const contact = await msg.getContact();
  client.db.set(`MenuSSH/${contact.id.user}`, {start: 1});
  client.db.set(`TesteSSH/${contact.id.user}`, {start: 1});
  require('./commands/menu.js')(client,msg,LOGIN_1,LOGIN_2,LOGIN_3);
    
  } else {
    client.sendMessage(chatID, '🔴 Essa aplicação está sem permissão de execução no momento.');
    return;
}}
});


client.on('message', async (message) => {
  let user = await message.getContact();
  require("./utilitarios/Navegation.js")(client,message,user,LOGIN_1,LOGIN_2,LOGIN_3,PixApi,DOWLOAD,LINK_SUPORTE);
});


PixApi.Net.on("success", (fatura) => {
  require('./receivers/receiver_payment.js')(client,fatura,LOGIN_1,LOGIN_2,LOGIN_3,LINK_SUPORTE,DOWLOAD);
});


client.initialize();